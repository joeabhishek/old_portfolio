FusionCharts-ExtJS-Wrapper
==========================

This is a wrapper around FusionCharts which lets you use FusionCharts charts as native ExtJS components.

It also comes with two fully working examples, one is demonstrating the usage of this plugin in ExtJS MVC pattern and 
the other demonstrating normal usage.
