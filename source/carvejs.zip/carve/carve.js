(function(){
  // Save a reference to the global object (`window` in the browser, `exports`
  // on the server).
  var root = this;

  // Save the previous value of the `Carve` variable, so that it can be
  // restored later on, if `noConflict` is used.
  var previousCarve = root.Carve;

  // The top-level namespace. All public Carve classes and modules will
  // be attached to this. Exported for both the browser and the server.
  var Carve;
  if (typeof exports !== 'undefined') {
    Carve = exports;
  } else {
    Carve = root.Carve= {};
  }

  // Require Underscore, if we're on the server, and it's not already present.
  var _ = root._;
  if (!_ && (typeof require !== 'undefined')) _ = require('underscore');

  Carve.noConflict = function() {
    root.Carve = previousCarve;
    return this;
  };

  var DataSource = Carve.DataSource = function(input) {
    this.data = {};
    this.fields = {};
    this.dataURL = null;

    this._initialize (input);
  };

  var Query = function(ds) {
    this.params = {
      sort: [],
      limit: [],
      group: [],
      select: [],
      filter: [],
      agg: [],
      subscribe: [],
      groupAll: [],
    };
    this.ds = ds;
    return this;
  };

  _.extend(DataSource.prototype, {
    _initialize: function(input) {
      this.fields = input['fields'];
      this.data = input['data'];
      this.dataURL = input['dataURL'];
      this.backEnd = input['backEnd'];
    },
    query: function () {
      return new Query(this);
    }
  });


  _.extend(Query.prototype, {
    asArray: function(callback) {
      this._asArrayLocal(callback);
    },

    _asArrayLocal: function(callback) {
      // this function will perform all the operations
      // and fetch the data
    
      var data = ds.data;

      if(this.params.filter.length > 0) {
        data = this._handleFilter (data); 
      
      }

      if(this.params.select.length > 0) {
        data = this._handleSelect(data);
      }

      if(this.params.sort.length > 0) {
        data = this._handleSort (data);
      }
    
      if(this.params.limit.length > 0){
        data = this._handleLimit(data);
      } 

      if(this.params.groupAll.length > 0) {
        data = this._handleGroupAll(data);
      }

      if(this.params.group.length > 0 && this.params.agg.length == 0) {
        data = this._handleGroup(data);
      }

     callback(data);
    },

    /**
     * Sort. Ascending by default.
     *
     * Usage:
     * q.sort([
     *   {field: 'age', order: 'desc'}
     * ])
     */
    sort: function (input) {
      this.params.sort.push(input);
      return this;
    },
    /**
     * Limit the number of items taken in the query
     *
     * Usage:
     *
     * q.limit({skip: 100, take: 10})
     * q.limit({take: 10})
     * q.limit({skip: 100})
     */
    limit: function (input) {
      this.params.limit.push(input);
      return this;
    },
    /**
     * Select only specific columns to be returned
     *
     * Usage:
     * q.select([
     *   {field: 'firstName'},
     *   {field: 'age'}
     * ])
     */
    select: function (input) {
      this.params.select = input;
      var aggParams = {
        fields: [],
        groupBy: {}
      };
      input.forEach(function(item) {
        if(item.aggregate === true){
          aggParams.fields.push({field: item.field, func: item.aggregateFunc});
        }
        if(item.groupBy === true) {
          aggParams.groupBy.field = item.field;
        }
      });
      this.params.agg.push(aggParams);
      return this;
    },


    /**
     * Filter some columns:
     *
     * Usage: 
     * q.filter({field: 'age', operator: '>', value: 32});
     * 
     * @param  {Object} input Filter
     */
    filter: function (input) {
      this.params.filter.push(input);
      return this;
    },

    removeFilter: function(position) {
      this.params.filter.splice(position, 1);
      return this;
    },

    clearFilters: function () {
      this.params.filter.length = 0;
    },

    monoFilter: function(input) {
      
      if(this.params.filter.length > 0) {
        if(this.params.filter[0].field == input.field && this.params.filter[0].value == input.value) {
          this.removeFilter(0);
          return this;
        } else {
          this.clearFilters();
          return this.filter(input);
        }
      } 
      
      this.clearFilters();
      return this.filter(input);
    },

    applyFilter: function(input) {
      //var test =  {field: 'type', operator: '=', value: "sodexo"};
      //this.params.filter.push(test);

      filterExists = false;
      //If the current filter is already applied, remove it
      if(this.params.filter.length > 0) {
        this.params.filter.forEach(function(item, idx, array) {
          if(item.field == input.field && item.value == input.value) {
              array.splice(idx, 1);
              filterExists = true;
          } 
        })
      }

      if(filterExists == true) {
        return this;
      } else {
          this.params.filter.push(input);
          return this;
      }

    },

    /**
     * Aggregate columns:
     *
     * Usage: 
     * q.aggregate({
     *   fields: [
     *     {field: 'age', func: 'sum'}, // TODO: find an alternative name for func
     *     {field: 'param1', func: 'stddev'} // TODO: find an alternative name for func
     *   ],
     *   groupBy: {
     *     field: 'firstName'
     *   }
     * });
     * 
     * @param  {Object} input Filter
     */
    aggregate: function (input) {
      this.params.agg.push(input);
      return this;
    },
    /**
     * Group 
     *
     * Usage:
     * q.group([
     *   {field: 'age'}
     * ])
     */
    group: function (input) {
      this.params.group = input;
      return this;
    },

    groupAll: function(input) {
      this.params.groupAll.push(input);
      return this;
    },

    subscribe: function (input) {
      this.params.subscribe = input;
      return this;
    },

    update: function() {
      that = this;
      this.asArray(function(data) {
        that.params.subscribe.forEach(function(func, idx, array){
          func(data);      
        });
      });
      return this;
    },

    _handleSort: function (data) {
      console.log("handling sort on ", this.params.sort[0].field);
      var field = this.params.sort[0].field;
      var multiplier = 1;

      if(this.params.sort[0].order == 'desc') {
        multiplier = -1;
      }

      return _.sortBy (data, function (val) {
        return val[field] * multiplier;
      })
    },

    _handleLimit: function(data) {
      if(typeof(this.params.limit[0].skip) !== 'undefined') {
        data = data.slice(this.params.limit[0].skip, data.length);
      }
      if(typeof(this.params.limit[0].take) !== 'undefined') {
        data = data.slice(0, this.params.limit[0].take);
      }
      return data;
    },

    _handleSelect: function(data) {
      var that = this;
      var newData = [];

      for(var i=0; i<data.length; i++) {
        var j = 0;
        var tmp = {};
        while(j < this.params.select.length) {
          var fieldName = this.params.select[j].field;
          tmp[fieldName] = data[i][fieldName];
          j += 1;
          
        }
        newData.push(tmp);
      }
      if(this.params.agg[0].fields.length > 0) {
        newData = this._handleAgg (newData);
      }
      return newData;
    },

    _handleGroup : function(data) {
      var self = this;
      return _.groupBy(data, function(item){
          return self.params.group[0].field; 
      });
    },

    _qualifier: function (row) {
    
      filters = this.params.filter 
      len = filters.length;

      for(var j=0; j<len; j++) {

        var fieldName = filters[j]['field'];
        var value = filters[j]['value'];
        var result = false;
        switch(filters[j]['operator']) {
          case '<':
            if(row[fieldName] < value) {
              return true;
            } else {
              continue;
            }
            break;
          case '>':
            if(row[fieldName] > value) {
              return true;
            } else {
              continue;
            }
            break;
          case '=':
            if(row[fieldName] == value) {
              return true;
            } else {
              continue;
            }
            break;
          default:
            return false;
        }
      }
    },

    _handleFilter : function(data) {
      var result = [];

      for (var i = data.length - 1; i >= 0; i--) {
        var row = data[i];

        if(this._qualifier(row)) {
          result.push(row);
        }
      };
      return result;
    },
    _handleAgg : function(data) {
     /* Params looks like: {
     *   fields: [
     *     {field: 'age', func: 'sum'}, // TODO: find an alternative name for func
     *     {field: 'param1', func: 'stddev'} // TODO: find an alternative name for func
     *   ],
     *   groupBy: {
     *     field: 'firstName'
     *   }
     * } */

      var buckets = {};
      var result = [];
      var aggItems = this.params.agg[0].fields;
      var groupByCol = this.params.agg[0].groupBy.field;

      for (var i = data.length - 1; i >= 0; i--) {
        var row = data[i];
        var groupByValue = row[groupByCol];
        var currentBucket = {};
        if(typeof(buckets[groupByValue]) !== 'undefined') {
          currentBucket = buckets[groupByValue];
        }

        for (var j = 0; j < aggItems.length; j++) {
          var item = aggItems[j];
          var val = row[item.field];
          if(typeof(currentBucket[item.field]) == 'undefined') {
            var defaultValue = 0;
            switch(item.func) {
              case 'sum':
                defaultValue = 0;
                break;
              case 'max':
                defaultValue = -1 * Infinity;
                break;
              case 'min':
                defaultValue = Infinity;
                break;
            }

            currentBucket[item.field] = defaultValue;
          }

          switch(item.func) {
            case 'sum':
              currentBucket [item.field] += val;
              break;
            case 'max':
              if(val > currentBucket [item.field]) {
                currentBucket[item.field] = val;
              }
              break;
          }
        }
        if(typeof(buckets[groupByValue]) == 'undefined') {
          buckets[groupByValue] = currentBucket;
          currentBucket[groupByCol] = groupByValue;
          result.push(currentBucket);
        }
      };
      return result

    },
    _handleGroupAll: function(data) {
      var func = this.params.groupAll[0].reduceFunc;
      var fieldName = this.params.groupAll[0].field;
      var result = {};
      switch(func) {
        case 'sum':
            total = _.reduce(data, function(memo, row){
              return memo + row[fieldName]
            }, 0);
            result[fieldName] = total;
      }
      return [result];
    }
  });

}).call(this);